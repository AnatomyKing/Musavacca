# item-model-renderer browserless refactor

This zip contains a Node-first refactor of `@iskallia-dev/item-model-renderer` so it can render queue GIFs directly inside GitHub Actions without Astro, a browser tab, Cloudflare Tunnel, or a worker page.

## What to delete from your old package

Delete these old browser/React files from your package:

- `lib/util/obj.utils.ts`
- `lib/render/Cuboid.tsx`
- `lib/render/TextureLoader.ts`
- `lib/render/ItemModelRender.tsx`
- `lib/render/ItemModelDisplayer.tsx`
- `lib/render/MeshMinecraftMaterial.ts`
- `lib/context/ItemModelGl.ctx.ts`
- `lib/main.tsx`

## Files included here

- new `package.json`
- new `tsconfig.json`
- new `lib/main.ts`
- new `lib/types.ts`
- new `lib/node/assets.ts`
- new `lib/node/resolve.ts`
- new `lib/node/generated-item.ts`
- new `lib/node/render.ts`
- new `lib/node/cli.ts`
- example workflow: `.github/workflows/discord-queue-gif-browserless.yml`

## Local install commands

From inside the package folder:

```bash
npm install
npm run build
```

## Local CLI usage

After building:

```bash
node dist/lib/node/cli.js render-queue \
  --assets-root src/main/resources/assets \
  --model-id musavacca:item/banana_phone \
  --blockstate-id musavacca:banana_pearl_block \
  --output ./out/queue.gif
```

## Linux / GitHub Actions native deps

For Ubuntu / GitHub Actions, install these before `npm install` if native modules need to compile:

```bash
sudo apt-get update
sudo apt-get install -y \
  build-essential \
  pkg-config \
  libxi-dev \
  libglu1-mesa-dev \
  libglew-dev \
  libcairo2-dev \
  libpango1.0-dev \
  libjpeg-dev \
  libgif-dev \
  librsvg2-dev
```

## Important note

This keeps your current blockstate behavior from the Astro version:

- it resolves referenced models
- it does **not** yet apply blockstate `x`, `y`, or `uvlock`

So the browserless output should match your current Astro/API behavior, not a full vanilla-perfect blockstate transform system.
